import random

import pygame

if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption('Rate Racing.exe')
    pygame.display.set_icon(pygame.image.load('images/icon.jpg'))
    size = width, height = 800, 600
    global screen
    screen = pygame.display.set_mode(size)


def generate_level():
    # открытие файла для записи матрицы
    level_rendering_file = open('level_rendering_file.txt', 'w')
    matrix = []
    k = 0
    while k != 10:
        # генерация матрицы в зависимости от кол-ва выбранных полос
        t = [str(random.randint(0, 1)) for _ in range(level_type[len(level_type) - 1])]
        if level_type[len(level_type) - 1] == 3:
            if t[0] != '1' or t[1] != '1' or t[2] != '1':
                matrix.append(t)
                k += 1
        if level_type[len(level_type) - 1] == 4:
            if t[0] != '1' or t[1] != '1' or t[2] != '1' or t[3] != '1':
                matrix.append(t)
                k += 1
        if level_type[len(level_type) - 1] == 5:
            if t[0] != '1' or t[1] != '1' or t[2] != '1' or t[3] != '1' or t[4] != 1:
                matrix.append(t)
                k += 1
    # запись матрицы в файл
    level_rendering_file.write(str(matrix))
    level_rendering_file.close()


def render_level():
    # открытие и чтение файла с матрицей
    level_rendering_file = open('level_rendering_file.txt', 'r')
    matrix_level = eval(level_rendering_file.read())
    level_rendering_file.close()
    # создание матрицы с изображением и коллизией ящиков
    global boxes
    boxes = []
    for i in matrix_level:
        # индекс ящика
        index = 0
        s = []
        for j in range(len(i)):
            if i[index] == '1':
                y = 0
                # загрузка изображения ящика
                box = pygame.image.load('images/boxes/type_' + str(random.randint(1, 4)) + '.png')
                if level_type[len(level_type) - 1] == 3:
                    if index == 0:
                        x = 240
                    if index == 1:
                        x = 400
                    if index == 2:
                        x = 560
                if level_type[len(level_type) - 1] == 4:
                    if index == 0:
                        x = 220
                    if index == 1:
                        x = 340
                    if index == 2:
                        x = 460
                    if index == 3:
                        x = 585
                if level_type[len(level_type) - 1] == 5:
                    if index == 0:
                        x = 200
                    if index == 1:
                        x = 307
                    if index == 2:
                        x = 410
                    if index == 3:
                        x = 505
                    if index == 4:
                        x = 595
                # загрузка коллизии ящика
                box_rect = box.get_rect(center=(x, y))
                s.append([box, box_rect, x])
                index += 1
            else:
                index += 1
        boxes.append(s)
    return boxes


def running_game(y, car_rect):
    # постановка машины
    if level_type[len(level_type) - 1] == 5:
        pos_car = 3
    else:
        pos_car = 2
    # количество кадров в секунду
    global fps
    fps = 60
    # индексация матрицы
    ind = 0
    # количество ящиков в кадре
    c = 0
    # координата ящиков по оси Y
    y = 0
    # выбор уровня сложности
    if pos_znak_complexity[len(pos_znak_complexity) - 1] == 390:
        v = 900
    if pos_znak_complexity[len(pos_znak_complexity) - 1] == 450:
        v = 750
    if pos_znak_complexity[len(pos_znak_complexity) - 1] == 510:
        v = 500
    if pos_znak_complexity[len(pos_znak_complexity) - 1] == 570:
        v = 560
    running = True
    best_count = 0
    WHITE = 255, 255, 255
    start_time = pygame.time.get_ticks()
    while running:
        # обработка событий
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                raise SystemExit
            if event.type == SONG_FINISHED:
                if select_track[len(select_track) - 1] + 1 > 7:
                    tracks[select_track[len(select_track) - 1]].stop()
                    select_track.append(1)
                    tracks[select_track[len(select_track) - 1]].play(-1)
                else:
                    tracks[select_track[len(select_track) - 1]].stop()
                    select_track.append(select_track[len(select_track) - 1] + 1)
                    tracks[select_track[len(select_track) - 1]].play(-1)
            if event.type == pygame.KEYDOWN:
                # смещение машины влево
                if event.key == pygame.K_a:
                    if level_type[len(level_type) - 1] == 3:
                        if pos_car == 1:
                            pass
                        if pos_car == 2:
                            car_rect = car.get_rect(center=(240, 520))
                            pos_car -= 1
                        if pos_car == 3:
                            car_rect = car.get_rect(center=(400, 520))
                            pos_car -= 1
                    if level_type[len(level_type) - 1] == 4:
                        if pos_car == 1:
                            pass
                        if pos_car == 2:
                            car_rect = car.get_rect(center=(220, 520))
                            pos_car -= 1
                        if pos_car == 3:
                            car_rect = car.get_rect(center=(340, 520))
                            pos_car -= 1
                        if pos_car == 4:
                            car_rect = car.get_rect(center=(460, 520))
                            pos_car -= 1
                    if level_type[len(level_type) - 1] == 5:
                        if pos_car == 1:
                            pass
                        if pos_car == 2:
                            car_rect = car.get_rect(center=(200, 520))
                            pos_car -= 1
                        if pos_car == 3:
                            car_rect = car.get_rect(center=(307, 520))
                            pos_car -= 1
                        if pos_car == 4:
                            car_rect = car.get_rect(center=(410, 520))
                            pos_car -= 1
                        if pos_car == 5:
                            car_rect = car.get_rect(center=(505, 520))
                            pos_car -= 1
                # смещение машины вправо
                if event.key == pygame.K_d:
                    if level_type[len(level_type) - 1] == 3:
                        if pos_car == 3:
                            pass
                        if pos_car == 2:
                            car_rect = car.get_rect(center=(560, 520))
                            pos_car += 1
                        if pos_car == 1:
                            car_rect = car.get_rect(center=(400, 520))
                            pos_car += 1
                    if level_type[len(level_type) - 1] == 4:
                        if pos_car == 4:
                            pass
                        if pos_car == 3:
                            car_rect = car.get_rect(center=(585, 520))
                            pos_car += 1
                        if pos_car == 2:
                            car_rect = car.get_rect(center=(460, 520))
                            pos_car += 1
                        if pos_car == 1:
                            car_rect = car.get_rect(center=(340, 520))
                            pos_car += 1
                    if level_type[len(level_type) - 1] == 5:
                        if pos_car == 5:
                            pass
                        if pos_car == 4:
                            car_rect = car.get_rect(center=(595, 520))
                            pos_car += 1
                        if pos_car == 3:
                            car_rect = car.get_rect(center=(505, 520))
                            pos_car += 1
                        if pos_car == 2:
                            car_rect = car.get_rect(center=(410, 520))
                            pos_car += 1
                        if pos_car == 1:
                            car_rect = car.get_rect(center=(307, 520))
                            pos_car += 1
                # пауза (в разработке)
                if event.key == pygame.K_ESCAPE:
                    pass
                # увеличение/уменьшение скорости
                if event.key == pygame.K_w:
                    if pos_znak_complexity[len(pos_znak_complexity) - 1] == 570:
                        v += 50
                if event.key == pygame.K_s:
                    if pos_znak_complexity[len(pos_znak_complexity) - 1] == 570:
                        v -= 50

        bests = text_font.render(str(best_count), True, WHITE)
        bests_w = bests.get_width()
        bests_h = bests.get_height()
        text_x = width - bests_w
        text_y = 0

        seconds = (pygame.time.get_ticks() - start_time) / 1000
        time_text = text_font.render(str(seconds), True, WHITE)
        time_text_w = time_text.get_width()
        time_text_h = time_text.get_height()
        time_text_x = 750
        time_text_y = bests_h

        # увеличение индекса матрицы, при условии, что текущие ящики на экране дошли до конца
        if y >= 600:
            y = 0
            best_count += 10
            ind += 1
        # органичение скорости не меньше 1
        if v <= 1:
            v = 1
        # при достижении конца матрицы вызов функций генерации матрицы
        if ind > len(boxes) - 1:
            ind = 0
            generate_level()
            render_level()
        # размещение изображения дороги в зависимости от кол-ва выбранных полос
        if level_type[len(level_type) - 1] == 3:
            screen.blit(road_x_3, road_x_3_rect)
        if level_type[len(level_type) - 1] == 4:
            screen.blit(road_x_4, road_x_4_rect)
        if level_type[len(level_type) - 1] == 5:
            screen.blit(road_x_5, road_x_5_rect)
        # размещение ящиков на экране
        global с
        if level_type[len(level_type) - 1] == 3:
            if len(boxes[0]) == 0:
                с = 0
            if len(boxes[ind]) == 1:
                box, box_rect, x = boxes[ind][0][0], boxes[ind][0][1], boxes[ind][0][2]
                screen.blit(box, box_rect)
                c = 1
            if len(boxes[ind]) == 2:
                box, box_rect, x = boxes[ind][0][0], boxes[ind][0][1], boxes[ind][0][2]
                box_1, box_1_rect, x_1 = boxes[ind][1][0], boxes[ind][1][1], boxes[ind][1][2]
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                c = 2
        if level_type[len(level_type) - 1] == 4:
            if len(boxes[0]) == 0:
                с = 0
            if len(boxes[ind]) == 1:
                box, box_rect, x = boxes[ind][0][0], boxes[ind][0][1], boxes[ind][0][2]
                screen.blit(box, box_rect)
                c = 1
            if len(boxes[ind]) == 2:
                box, box_rect, x = boxes[ind][0][0], boxes[ind][0][1], boxes[ind][0][2]
                box_1, box_1_rect, x_1 = boxes[ind][1][0], boxes[ind][1][1], boxes[ind][1][2]
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                c = 2
            if len(boxes[ind]) == 3:
                box, box_rect, x = boxes[ind][0][0], boxes[ind][0][1], boxes[ind][0][2]
                box_1, box_1_rect, x_1 = boxes[ind][1][0], boxes[ind][1][1], boxes[ind][1][2]
                box_2, box_2_rect, x_2 = boxes[ind][2][0], boxes[ind][2][1], boxes[ind][2][2]
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                screen.blit(box_2, box_2_rect)
                c = 3
        if level_type[len(level_type) - 1] == 5:
            if len(boxes[0]) == 0:
                с = 0
            if len(boxes[ind]) == 1:
                box, box_rect, x = boxes[ind][0][0], boxes[ind][0][1], boxes[ind][0][2]
                screen.blit(box, box_rect)
                c = 1
            if len(boxes[ind]) == 2:
                box, box_rect, x = boxes[ind][0][0], boxes[ind][0][1], boxes[ind][0][2]
                box_1, box_1_rect, x_1 = boxes[ind][1][0], boxes[ind][1][1], boxes[ind][1][2]
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                c = 2
            if len(boxes[ind]) == 3:
                box, box_rect, x = boxes[ind][0][0], boxes[ind][0][1], boxes[ind][0][2]
                box_1, box_1_rect, x_1 = boxes[ind][1][0], boxes[ind][1][1], boxes[ind][1][2]
                box_2, box_2_rect, x_2 = boxes[ind][2][0], boxes[ind][2][1], boxes[ind][2][2]
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                screen.blit(box_2, box_2_rect)
                c = 3
            if len(boxes[ind]) == 4:
                box, box_rect, x = boxes[ind][0][0], boxes[ind][0][1], boxes[ind][0][2]
                box_1, box_1_rect, x_1 = boxes[ind][1][0], boxes[ind][1][1], boxes[ind][1][2]
                box_2, box_2_rect, x_2 = boxes[ind][2][0], boxes[ind][2][1], boxes[ind][2][2]
                box_3, box_3_rect, x_3 = boxes[ind][3][0], boxes[ind][3][1], boxes[ind][3][2]
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                screen.blit(box_2, box_2_rect)
                screen.blit(box_3, box_3_rect)
                c = 4
        # чтобы ящики не оставляли за собой след, повторное размещение изображения дороги,
        # в зависимости от выбранного кол-ва полос
        if level_type[len(level_type) - 1] == 3:
            screen.blit(road_x_3, road_x_3_rect)
        if level_type[len(level_type) - 1] == 4:
            screen.blit(road_x_4, road_x_4_rect)
        if level_type[len(level_type) - 1] == 5:
            screen.blit(road_x_5, road_x_5_rect)
        # перемещения ящиков вниз по экрану
        if level_type[len(level_type) - 1] == 3:
            if c == 0:
                ind += 1
            if c == 1:
                box_rect = box.get_rect(center=(x, y))
                screen.blit(box, box_rect)
                y += v / fps
            if c == 2:
                box_rect = box.get_rect(center=(x, y))
                box_1_rect = box_1.get_rect(center=(x_1, y))
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                y += v / fps
        if level_type[len(level_type) - 1] == 4:
            if c == 0:
                ind += 1
            if c == 1:
                box_rect = box.get_rect(center=(x, y))
                screen.blit(box, box_rect)
                y += v / fps
            if c == 2:
                box_rect = box.get_rect(center=(x, y))
                box_1_rect = box_1.get_rect(center=(x_1, y))
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                y += v / fps
            if c == 3:
                box_rect = box.get_rect(center=(x, y))
                box_1_rect = box_1.get_rect(center=(x_1, y))
                box_2_rect = box_2.get_rect(center=(x_2, y))
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                screen.blit(box_2, box_2_rect)
                y += v / fps
        if level_type[len(level_type) - 1] == 5:
            if c == 0:
                ind += 1
            if c == 1:
                box_rect = box.get_rect(center=(x, y))
                screen.blit(box, box_rect)
                y += v / fps
            if c == 2:
                box_rect = box.get_rect(center=(x, y))
                box_1_rect = box_1.get_rect(center=(x_1, y))
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                y += v / fps
            if c == 3:
                box_rect = box.get_rect(center=(x, y))
                box_1_rect = box_1.get_rect(center=(x_1, y))
                box_2_rect = box_2.get_rect(center=(x_2, y))
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                screen.blit(box_2, box_2_rect)
                y += v / fps
            if c == 4:
                box_rect = box.get_rect(center=(x, y))
                box_1_rect = box_1.get_rect(center=(x_1, y))
                box_2_rect = box_2.get_rect(center=(x_2, y))
                box_3_rect = box_3.get_rect(center=(x_3, y))
                screen.blit(box, box_rect)
                screen.blit(box_1, box_1_rect)
                screen.blit(box_2, box_2_rect)
                screen.blit(box_3, box_3_rect)
                y += v / fps
        # проверка столкновений машины с ящиками, в зависимости от выбранного кол-ва полос
        global time_res, best_res
        if c == 1:
            if car_rect.collidepoint(box_rect.center):
                running = False
                time_res = seconds
                best_res = best_count
                game_over()
        if c == 2:
            if car_rect.collidepoint(box_rect.center) or car_rect.collidepoint(box_1_rect.center):
                running = False
                time_res = seconds
                best_res = best_count
                game_over()
        if c == 3:
            if car_rect.collidepoint(box_rect.center) or car_rect.collidepoint(
                    box_1_rect.center) or car_rect.collidepoint(box_2_rect.center):
                running = False
                time_res = seconds
                best_res = best_count
                game_over()
        if c == 4:
            if car_rect.collidepoint(box_rect.center) or car_rect.collidepoint(
                    box_1_rect.center) or car_rect.collidepoint(box_2_rect.center) or car_rect.collidepoint(
                box_3_rect.center):
                running = False
                time_res = seconds
                best_res = best_count
                game_over()

        # размещение элементов
        screen.blit(car, car_rect)
        screen.blit(bests, (text_x, text_y))
        screen.blit(time_text, (time_text_x, time_text_y))
        # обновления экрана
        pygame.display.flip()
        clock.tick(fps)


def game_over():
    # установка музыки на паузу
    track_play.pause()
    run_game_over_menu = True
    # проигрывание звука поражения
    game_over_track.play()
    while run_game_over_menu:
        # обработка событий
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                raise SystemExit
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                x = pos[0]
                y = pos[1]
                if 760 >= x >= 680 and 555 >= y >= 480:
                    run_game_over_menu = False
                    generate_level()
                    render_level()
                    track_play.unpause()
                    running_game(y, car_rect)
                if 755 >= x >= 680 and 455 >= y >= 380:
                    run_game_over_menu = False
                    run_menu(img, play_btn, play_btn_rect, exit_btn, exit_btn_rect, options_btn, options_btn_rect)
                if 755 >= x >= 680 and 355 >= y >= 280:
                    print(time_res, best_res)
                    bests_file = open('bests_file.txt', 'a')
                    a = str(tuple((name_player, time_res, best_res, level_type[len(level_type) - 1],
                                   pos_znak_complexity[len(pos_znak_complexity) - 1]))) + '\n'
                    if a not in repeat_records:
                        bests_file.write(a)
                        bests_file.close()
                        repeat_records.append(a)
                    else:
                        pass

        # размещение элементов
        screen.blit(game_over_display, game_over_display_rect)
        screen.blit(rerun_btn, rerun_btn_rect)
        screen.blit(home_btn, home_btn_rect)
        screen.blit(save_results_btn, save_results_btn_rect)
        # отрисовка курсора
        pos = pygame.mouse.get_pos()
        x = pos[0]
        y = pos[1]
        draw_cursor(screen, x, y)
        # обновление дисплея
        pygame.display.flip()
        clock.tick(fps)


def draw_cursor(screen, x, y):
    screen.blit(cursor, (x, y))


def run_menu(img, play_btn, play_btn_rect, exit_btn, exit_btn_rect, options_btn, options_btn_rect):
    # вызов функций генерации матрицы препятствий
    generate_level()
    render_level()
    # загрузка изображения машины
    global car
    if car_select[len(car_select) - 1] == 1:
        car = pygame.image.load('images/cars/car_type_1.png')
    if car_select[len(car_select) - 1] == 2:
        car = pygame.image.load('images/cars/car_type_2.png')
    # размещение машины на дороге до старта
    global car_rect
    if level_type[len(level_type) - 1] == 3:
        car_rect = car.get_rect(center=(400, 520))
    if level_type[len(level_type) - 1] == 4:
        car_rect = car.get_rect(center=(340, 520))
    if level_type[len(level_type) - 1] == 5:
        car_rect = car.get_rect(center=(410, 520))
    running_menu = True
    global repeat
    repeat = True
    # снятие музыки с паузы
    global bests
    track_play.unpause()
    file = open('bests_file.txt', 'r')
    bests = file.readlines()
    for i in range(len(bests)):
        bests[i] = eval(bests[i].strip())
    repeat_records.extend(bests)
    PURPLE = 148, 0, 211
    while running_menu:
        # анимация
        img += 1
        if img >= 96:
            img = 0
        # обработка событий
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                raise SystemExit
            if event.type == SONG_FINISHED:
                if select_track[len(select_track) - 1] + 1 > 7:
                    tracks[select_track[len(select_track) - 1]].stop()
                    select_track.append(1)
                    tracks[select_track[len(select_track) - 1]].play(-1)
                else:
                    tracks[select_track[len(select_track) - 1]].stop()
                    select_track.append(select_track[len(select_track) - 1] + 1)
                    tracks[select_track[len(select_track) - 1]].play(-1)
            if event.type == pygame.MOUSEBUTTONDOWN:
                x = pygame.mouse.get_pos()[0]
                y = pygame.mouse.get_pos()[1]
                if 625 >= x >= 460 and 476 >= y >= 425:
                    exit_btn_rect = exit_btn.get_rect(center=(550, 456))
                    raise SystemExit
                if 330 >= x >= 185 and 476 >= y >= 427:
                    play_btn_rect = play_btn.get_rect(center=(260, 450))
                    running_game(y, car_rect)
                if 550 >= x >= 265 and 574 >= y >= 522:
                    options_btn_rect = options_btn.get_rect(center=(410, 550))
                    screen.blit(options_btn, options_btn_rect)
                    running_menu = False
                    func_running_options(play_music, music_on_btn, music_on_btn_rect, music_off_btn, music_off_btn_rect)
                if 785 >= x >= 710 and 583 >= y >= 480:
                    running_menu = False
                    run_bests_menu()
                if 105 >= x >= 27 and 575 >= y >= 500:
                    loading_animation()

        name_player_tab_text = text_font.render(str(names[len(names) - 1]), True, PURPLE)
        name_player_tab_w = name_player_tab_text.get_width()
        name_player_tab_h = name_player_tab_text.get_height()
        name_player_tab_x = 32
        name_player_tab_y = 475

        # размещение элементов
        tracks[select_track[len(select_track) - 1]].set_volume(volume[len(volume) - 1])
        screen.blit(all_imgs[img], all_imgs[img].get_rect())
        screen.blit(play_btn, play_btn_rect)
        screen.blit(exit_btn, exit_btn_rect)
        screen.blit(options_btn, options_btn_rect)
        screen.blit(name_game, name_game_rect)
        screen.blit(bests_btn, bests_btn_rect)
        screen.blit(change_your_nickname_btn, change_your_nickname_btn_rect)
        screen.blit(name_player_tab_text, (name_player_tab_x, name_player_tab_y))
        # отрисовка курсора
        pos = pygame.mouse.get_pos()
        x = pos[0]
        y = pos[1]
        draw_cursor(screen, x, y)
        # обновление дисплея
        pygame.display.flip()
        clock.tick(fps)


def func_running_options(play_music, music_on_btn, music_on_btn_rect, music_off_btn, music_off_btn_rect):
    running_options = True
    img = 0
    while running_options:
        # анимация
        img += 1
        if img >= 96:
            img = 0

        # обработка событий
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                raise SystemExit
            if event.type == SONG_FINISHED:
                if select_track[len(select_track) - 1] + 1 > 7:
                    tracks[select_track[len(select_track) - 1]].stop()
                    select_track.append(1)
                    tracks[select_track[len(select_track) - 1]].play(-1)
                else:
                    tracks[select_track[len(select_track) - 1]].stop()
                    select_track.append(select_track[len(select_track) - 1] + 1)
                    tracks[select_track[len(select_track) - 1]].play(-1)
            if event.type == pygame.MOUSEBUTTONDOWN:
                x = pygame.mouse.get_pos()[0]
                y = pygame.mouse.get_pos()[1]
                # отключение звука
                if 101 >= x >= 25 and 102 >= y >= 25:
                    if play_music[len(play_music) - 1] == 0:
                        volume.append(volume[len(volume) - 2])
                        play_music.append(1)
                    elif play_music[len(play_music) - 1] == 1:
                        volume.append(0)
                        play_music.append(0)
                # выход в главное меню
                if 110 >= x >= 25 and 575 >= y >= 500:
                    running_options = False
                    run_menu(img, play_btn, play_btn_rect, exit_btn, exit_btn_rect, options_btn, options_btn_rect)
                # выбор кол-ва полос дороги
                if 290 >= x >= 204 and 340 >= y >= 255:
                    pos_znak.append(250)
                    level_type.append(3)
                if 490 >= x >= 400 and 340 >= y >= 255:
                    pos_znak.append(450)
                    level_type.append(4)
                if 690 >= x >= 605 and 340 >= y >= 255:
                    pos_znak.append(650)
                    level_type.append(5)
                # выбор машины
                if 577 >= x >= 537 and 497 >= y >= 456:
                    pos_znak_car.append(480)
                    car_select.append(1)
                if 577 >= x >= 537 and 565 >= y >= 527:
                    pos_znak_car.append(550)
                    car_select.append(2)
                # выбор уровня сложности
                if 377 >= x >= 337 and 405 >= y >= 367:
                    pos_znak_complexity.append(390)
                if 377 >= x >= 337 and 464 >= y >= 425:
                    pos_znak_complexity.append(450)
                if 377 >= x >= 337 and 525 >= y >= 486:
                    pos_znak_complexity.append(510)
                if 377 >= x >= 337 and 585 >= y >= 545:
                    pos_znak_complexity.append(570)
                if 205 >= x >= 145 and 575 >= y >= 520:
                    if repeat_music[len(repeat_music) - 1] == 0:
                        if select_track[len(select_track) - 1] - 1 < 1:
                            tracks[select_track[len(select_track) - 1]].stop()
                            select_track.append(7)
                            tracks[select_track[len(select_track) - 1]].play(-1)
                        else:
                            tracks[select_track[len(select_track) - 1]].stop()
                            select_track.append(select_track[len(select_track) - 1] - 1)
                            tracks[select_track[len(select_track) - 1]].play(-1)
                    else:
                        pass
                if 290 >= x >= 225 and 575 >= y >= 520:
                    if repeat_music[len(repeat_music) - 1] == 0:
                        if select_track[len(select_track) - 1] + 1 > 7:
                            tracks[select_track[len(select_track) - 1]].stop()
                            select_track.append(1)
                            tracks[select_track[len(select_track) - 1]].play(-1)
                        else:
                            tracks[select_track[len(select_track) - 1]].stop()
                            select_track.append(select_track[len(select_track) - 1] + 1)
                            tracks[select_track[len(select_track) - 1]].play(-1)
                    else:
                        pass
                # регулировка громкости музыки
                if 90 >= x >= 40 and 190 >= y >= 140:
                    a = img_v[len(img_v) - 1] + 1
                    if a <= 10:
                        if volume[len(volume) - 1] == 0:
                            volume.insert(int(len(volume) - 2), volume[len(volume) - 2] - 0.1)
                        else:
                            img_v.append(a)
                            volume.append(volume[len(volume) - 1] + 0.1)
                if 100 >= x >= 37 and 330 >= y >= 300:
                    a = img_v[len(img_v) - 1] - 1
                    if a >= 0:
                        if volume[len(volume) - 1] == 0:
                            volume.insert(int(len(volume) - 2), volume[len(volume) - 2] - 0.1)
                        else:
                            img_v.append(a)
                            volume.append(volume[len(volume) - 1] - 0.1)
                if 113 >= x >= 20 and 370 >= y >= 345:
                    if repeat_music[len(repeat_music) - 1] == 0:
                        tracks[select_track[len(select_track) - 1]].stop()
                        select_track.append(8)
                        tracks[select_track[len(select_track) - 1]].play(-1)
                        repeat_music.append(1)
                    else:
                        tracks[select_track[len(select_track) - 1]].stop()
                        select_track.append(1)
                        tracks[select_track[len(select_track) - 1]].play(-1)
                        repeat_music.append(0)

        # установка громкости музыки
        tracks[select_track[len(select_track) - 1]].set_volume(volume[len(volume) - 1])
        # размещение цифр уровня громкости музыки
        screen.blit(all_imgs[img], all_imgs[img].get_rect())
        # смена кнопки вкл/выкл музыки
        if play_music[len(play_music) - 1] == 1:
            screen.blit(music_on_btn, music_on_btn_rect)
        elif play_music[len(play_music) - 1] == 0:
            screen.blit(music_off_btn, music_off_btn_rect)

        # размещение эдементов
        screen.blit(home_btn, home_btn_options_rect)
        screen.blit(frame_1, frame_1_rect)
        screen.blit(frame_2, frame_2_rect)
        screen.blit(frame_3, frame_3_rect)
        screen.blit(znak, znak.get_rect(center=(pos_znak[len(pos_znak) - 1], 300)))
        screen.blit(num_3, num_3_rect)
        screen.blit(num_4, num_4_rect)
        screen.blit(num_5, num_5_rect)
        screen.blit(car_type_1_options, car_type_1_options_rect)
        screen.blit(car_type_2_options, car_type_2_options_rect)
        screen.blit(num_lines_road_text, num_lines_road_text_rect)
        screen.blit(frame_from_car, frame_from_car_rect)
        screen.blit(frame_from_car_2, frame_from_car_2_rect)
        screen.blit(znak_from_car, znak_from_car.get_rect(center=(560, pos_znak_car[len(pos_znak_car) - 1])))
        screen.blit(select_car_text, select_car_text_rect)
        screen.blit(plus_volume_btn, plus_volume_btn_rect)
        screen.blit(minus_volume_btn, minus_volume_btn_rect)
        screen.blit(reg_volume_nums[img_v[len(img_v) - 1]],
                    reg_volume_nums[img_v[len(img_v) - 1]].get_rect(center=(70, 250)))
        screen.blit(volume_text, volume_text_rect)
        screen.blit(hard_text, hard_text_rect)
        screen.blit(medium_text, medium_text_rect)
        screen.blit(easy_text, easy_text_rect)
        screen.blit(custom_text, custom_text_rect)
        screen.blit(frame_select_level_h, frame_select_level_h_rect)
        screen.blit(frame_select_level_m, frame_select_level_m_rect)
        screen.blit(frame_select_level_e, frame_select_level_e_rect)
        screen.blit(frame_select_level_c, frame_select_level_c_rect)
        screen.blit(znak_from_select_level,
                    znak_from_select_level.get_rect(center=(360, pos_znak_complexity[len(pos_znak_complexity) - 1])))
        screen.blit(select_track_btn_1, select_track_btn_1_rect)
        screen.blit(select_track_btn_2, select_track_btn_2_rect)
        screen.blit(select_track_text, select_track_text_rect)
        if repeat_music[len(repeat_music) - 1] == 0:
            screen.blit(replay_music_btn, replay_music_btn_rect)
        if repeat_music[len(repeat_music) - 1] == 1:
            screen.blit(clicked_replay_music_btn, replay_music_btn_rect)
        # отрисовка курсора
        pos = pygame.mouse.get_pos()
        x = pos[0]
        y = pos[1]
        draw_cursor(screen, x, y)
        # обновление дисплея
        pygame.display.flip()
        clock.tick(60)


def run_bests_menu():
    running_bests = True
    img = 0
    len_bests = len(bests)
    global PURPLE
    PURPLE = 148, 0, 211
    page = 0
    while running_bests:
        img += 1
        if img >= 96:
            img = 0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                raise SystemExit
            if event.type == pygame.MOUSEBUTTONDOWN:
                x = pygame.mouse.get_pos()[0]
                y = pygame.mouse.get_pos()[1]
                if 103 >= x >= 29 and 575 >= y >= 500:
                    running_bests = False
                    run_menu(img, play_btn, play_btn_rect, exit_btn, exit_btn_rect, options_btn, options_btn_rect)
                if 680 >= x >= 615 and 575 >= y >= 520:
                    try:
                        float(len_bests / 5)
                    except ValueError:
                        if page + 1 > (len_bests / 5) + 1:
                            pass
                        else:
                            page += 1
                    else:
                        if page + 1 > len_bests / 5:
                            pass
                        else:
                            page += 1
                if 225 >= x >= 160 and 575 >= y >= 520:
                    page -= 1
                    if page < 0:
                        page = 0
                if 745 >= x >= 710 and 580 >= y >= 515:
                    file = open('bests_file.txt', 'w')
                    file.truncate()
                    file.close()
                    bests.clear()

        screen.blit(all_imgs[img], all_imgs[img].get_rect())
        screen.blit(home_btn_bests, home_btn_bests_rect)
        screen.blit(name_table_bests, name_table_bests_rect)
        screen.blit(time_table_text, time_table_text_rect)
        screen.blit(best_table_text, best_table_text_rect)
        screen.blit(lines_table_text, lines_table_text_rect)
        screen.blit(level_table_text, level_table_text_rect)
        screen.blit(num_1_table, num_1_table_rect)
        screen.blit(num_2_table, num_2_table_rect)
        screen.blit(num_3_table, num_3_table_rect)
        screen.blit(num_4_table, num_4_table_rect)
        screen.blit(num_5_table, num_5_table_rect)
        screen.blit(select_record_btn_1, select_record_btn_1_rect)
        screen.blit(select_record_btn_2, select_record_btn_2_rect)
        screen.blit(clear_best_btn, clear_best_btn_rect)

        el = page * 5

        for i in range(5):
            if i == 0:
                y = 95
            if i == 1:
                y = 170
            if i == 2:
                y = 250
            if i == 3:
                y = 330
            if i == 4:
                y = 410
            for j in range(5):
                try:
                    name_player_tab, time, best, line, lvl = bests[el][0], bests[el][1], bests[el][2], bests[el][3], \
                                                             bests[el][4]
                except IndexError:
                    break

                name_player_tab_text = text_font.render(str(name_player_tab), True, PURPLE)
                name_player_tab_w = name_player_tab_text.get_width()
                name_player_tab_h = name_player_tab_text.get_height()
                name_player_tab_x = 70
                name_player_tab_y = y
                screen.blit(name_player_tab_text, (name_player_tab_x, name_player_tab_y))

                time_tab_text = text_font.render(str(time), True, PURPLE)
                time_tab_w = time_tab_text.get_width()
                time_tab_h = time_tab_text.get_height()
                time_tab_x = 220
                time_tab_y = y
                screen.blit(time_tab_text, (time_tab_x, time_tab_y))

                best_tab_text = text_font.render(str(best), True, PURPLE)
                best_tab_w = best_tab_text.get_width()
                best_tab_h = best_tab_text.get_height()
                best_tab_x = 390
                best_tab_y = y
                screen.blit(best_tab_text, (best_tab_x, best_tab_y))

                line_tab_text = text_font.render(str(line), True, PURPLE)
                line_tab_w = line_tab_text.get_width()
                line_tab_h = line_tab_text.get_height()
                line_tab_x = 540
                line_tab_y = y
                screen.blit(line_tab_text, (line_tab_x, line_tab_y))

                if lvl == 390:
                    lvl_tab_text = text_font.render('hard', True, PURPLE)
                if lvl == 450:
                    lvl_tab_text = text_font.render('medium', True, PURPLE)
                if lvl == 510:
                    lvl_tab_text = text_font.render('easy', True, PURPLE)
                if lvl == 570:
                    lvl_tab_text = text_font.render('custom', True, PURPLE)
                lvl_tab_w = lvl_tab_text.get_width()
                lvl_tab_h = lvl_tab_text.get_height()
                lvl_tab_x = 650
                lvl_tab_y = y
                screen.blit(lvl_tab_text, (lvl_tab_x, lvl_tab_y))
            el += 1

        pos = pygame.mouse.get_pos()
        x = pos[0]
        y = pos[1]
        draw_cursor(screen, x, y)
        pygame.display.flip()
        clock.tick(60)


def loading_animation():
    img_l = 0
    running_loading = True
    input_box = pygame.Rect(390, 450, 140, 32)
    color_inactive = pygame.Color('lightskyblue3')
    color_active = pygame.Color('dodgerblue2')
    text = ''
    color = color_inactive
    active = False
    while running_loading:
        txt_surface = text_font.render(text, True, color)
        width = max(200, txt_surface.get_width() + 10)
        input_box.w = width

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                raise SystemExit
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box.collidepoint(event.pos):
                    active = not active
                else:
                    active = False
                color = color_active if active else color_inactive
            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        if text == '' or len(text) > 8:
                            pass
                        else:
                            global name_player
                            name_player = text
                            names.append(name_player)
                            run_menu(img, play_btn, play_btn_rect, exit_btn, exit_btn_rect, options_btn,
                                     options_btn_rect)
                            text = ''
                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                    else:
                        text += event.unicode

        if repeat:
            img_l = 119
        screen.blit(loading_imgs[img_l], loading_imgs[img_l].get_rect())
        if img_l == 119:
            screen.blit(txt_surface, (input_box.x + 5, input_box.y + 5))
            screen.blit(your_name_text, your_name_text_rect)
            pygame.draw.rect(screen, color, input_box, 2)
            pos = pygame.mouse.get_pos()
            x = pos[0]
            y = pos[1]
            draw_cursor(screen, x, y)
        else:
            img_l += 1
        pygame.display.flip()
        screen.blit(txt_surface, (input_box.x + 5, input_box.y + 5))
        pygame.draw.rect(screen, color, input_box, 2)
        clock.tick(60)


repeat = False
repeat_music = [0]
names = []
# курсор
pygame.mouse.set_visible(False)
cursor = pygame.image.load('images/cursor.png')
# музыка
volume = [0.1]
select_track = [1]
replay_music = [0]
SONG_FINISHED = pygame.USEREVENT + 1
pygame.mixer.music.set_endevent(SONG_FINISHED)
game_over_track = pygame.mixer.Sound("sounds/game_over_sound.ogg")
tracks = {}
for x in range(1, 8):
    track = pygame.mixer.Sound('sounds/sound_' + str(x) + '.ogg')
    tracks[x] = track
tracks[8] = pygame.mixer.Sound('sounds/united_sound.ogg')
track_play = tracks[select_track[len(select_track) - 1]].play(-1)
tracks[select_track[len(select_track) - 1]].set_volume(len(volume) - 1)
track_play.pause()
# загрузка изображений анимации в главном меню и меню настроек
all_imgs = {}
for img in range(0, 96):
    all_imgs[img] = pygame.image.load('images/start_animation/' + str(img) + '.gif')
# повтор рекордов
repeat_records = []
# загрузка изображений цифр уровня громкости
img_v = [1]
reg_volume_nums = {}
for x in range(0, 11):
    reg_volume_nums[x] = pygame.image.load('images/regulation_volume_nums/' + str(x) + '.png')
# загрузка изображения loading
loading_imgs = {}
for x in range(120):
    loading_imgs[x] = pygame.image.load('images/loading_animation/' + str(x) + '.gif')
# обозначение положений курсоров
level_type = [3]
pos_znak = [250]
pos_znak_car = [480]
car_select = [1]
pos_znak_complexity = [450]
# счетчики времени и рекорда
text_font = pygame.font.Font('images/fonts/font.ttf', 20)
# загрузка изображений и коллизий объектов
road_x_3 = pygame.image.load('images/roads/road_x_3.jpg')
road_x_3_rect = road_x_3.get_rect()
road_x_4 = pygame.image.load('images/roads/road_x_4.jpg')
road_x_4_rect = road_x_4.get_rect()
road_x_5 = pygame.image.load('images/roads/road_x_5.jpg')
road_x_5_rect = road_x_5.get_rect()
# знаки (галочки)
znak = pygame.image.load('images/tokens/token.png')
znak_from_car = pygame.image.load('images/tokens/token_for_car.png')
znak_from_select_level = pygame.image.load('images/tokens/token_for_select_level.png')
# рамки
frame_1 = pygame.image.load('images/frames/frame.png')
frame_1_rect = frame_1.get_rect(center=(250, 300))
frame_2 = pygame.image.load('images/frames/frame.png')
frame_2_rect = frame_2.get_rect(center=(450, 300))
frame_3 = pygame.image.load('images/frames/frame.png')
frame_3_rect = frame_3.get_rect(center=(650, 300))
frame_from_car = pygame.image.load('images/frames/frame_for_car.png')
frame_from_car_rect = frame_from_car.get_rect(center=(560, 480))
frame_from_car_2 = pygame.image.load('images/frames/frame_for_car.png')
frame_from_car_2_rect = frame_from_car_2.get_rect(center=(560, 550))
# цифры кол-ва полос
num_3 = pygame.image.load('images/nums/3.png')
num_3_rect = num_3.get_rect(center=(250, 150))
num_4 = pygame.image.load('images/nums/4.png')
num_4_rect = num_4.get_rect(center=(450, 150))
num_5 = pygame.image.load('images/nums/5.png')
num_5_rect = num_5.get_rect(center=(650, 150))
# тексты
select_car_text = pygame.image.load('images/texts/select_car_text.png')
select_car_text_rect = select_car_text.get_rect(center=(630, 420))
volume_text = pygame.image.load('images/texts/volume_text.png')
volume_text_rect = volume_text.get_rect(center=(65, 120))
hard_text = pygame.image.load('images/texts/hard_text.png')
hard_text_rect = hard_text.get_rect(center=(430, 390))
medium_text = pygame.image.load('images/texts/medium_text.png')
medium_text_rect = medium_text.get_rect(center=(450, 450))
easy_text = pygame.image.load('images/texts/easy_text.png')
easy_text_rect = easy_text.get_rect(center=(430, 510))
custom_text = pygame.image.load('images/texts/custom_text.png')
custom_text_rect = custom_text.get_rect(center=(447, 570))
name_game = pygame.image.load('images/texts/name_game.png')
name_game_rect = name_game.get_rect(center=(410, 100))
num_lines_road_text = pygame.image.load('images/texts/num_lines_road_text.png')
num_lines_road_text_rect = num_lines_road_text.get_rect(center=(450, 40))
select_track_text = pygame.image.load('images/texts/select_track_text.png')
select_track_text_rect = select_track_text.get_rect(center=(222, 510))
name_table_bests = pygame.image.load('images/texts/bests_table/name_text.png')
name_table_bests_rect = name_table_bests.get_rect(center=(115, 30))
time_table_text = pygame.image.load('images/texts/bests_table/time_text.png')
time_table_text_rect = time_table_text.get_rect(center=(260, 30))
best_table_text = pygame.image.load('images/texts/bests_table/best_text.png')
best_table_text_rect = best_table_text.get_rect(center=(410, 30))
lines_table_text = pygame.image.load('images/texts/bests_table/lines_text.png')
lines_table_text_rect = lines_table_text.get_rect(center=(550, 30))
level_table_text = pygame.image.load('images/texts/bests_table/level_text.png')
level_table_text_rect = level_table_text.get_rect(center=(690, 30))
num_1_table = pygame.image.load('images/texts/bests_table/nums/num_1.png')
num_1_table_rect = num_1_table.get_rect(center=(20, 95))
num_2_table = pygame.image.load('images/texts/bests_table/nums/num_2.png')
num_2_table_rect = num_2_table.get_rect(center=(20, 170))
num_3_table = pygame.image.load('images/texts/bests_table/nums/num_3.png')
num_3_table_rect = num_3_table.get_rect(center=(20, 250))
num_4_table = pygame.image.load('images/texts/bests_table/nums/num_4.png')
num_4_table_rect = num_4_table.get_rect(center=(20, 330))
num_5_table = pygame.image.load('images/texts/bests_table/nums/num_5.png')
num_5_table_rect = num_5_table.get_rect(center=(20, 410))
your_name_text = pygame.image.load('images/texts/your_name_text.png')
your_name_text_rect = your_name_text.get_rect(center=(260, 463))
# рамка выбора уровня сложности
frame_select_level_h = pygame.image.load('images/frames/frame_for_select_level.png')
frame_select_level_h_rect = frame_select_level_h.get_rect(center=(360, 390))
frame_select_level_m = pygame.image.load('images/frames/frame_for_select_level.png')
frame_select_level_m_rect = frame_select_level_m.get_rect(center=(360, 450))
frame_select_level_e = pygame.image.load('images/frames/frame_for_select_level.png')
frame_select_level_e_rect = frame_select_level_e.get_rect(center=(360, 510))
frame_select_level_c = pygame.image.load('images/frames/frame_for_select_level.png')
frame_select_level_c_rect = frame_select_level_c.get_rect(center=(360, 570))
# машины
car_type_1_options = pygame.image.load('images/cars/car_type_1_options.png')
car_type_1_options_rect = car_type_1_options.get_rect(center=(650, 480))
car_type_2_options = pygame.image.load('images/cars/car_type_2_options.png')
car_type_2_options_rect = car_type_2_options.get_rect(center=(650, 550))
# дисплей поражения
game_over_display = pygame.image.load('images/game_over_display.jpg')
game_over_display_rect = game_over_display.get_rect()
# кнопки
rerun_btn = pygame.image.load('images/buttons/rerun_btn.png')
rerun_btn_rect = rerun_btn.get_rect(center=(720, 520))
home_btn = pygame.image.load('images/buttons/home_btn.png')
home_btn_rect = home_btn.get_rect(center=(720, 420))
home_btn_options_rect = home_btn.get_rect(center=(70, 540))
play_btn = pygame.image.load('images/buttons/start_btn.png')
play_btn_rect = play_btn.get_rect(center=(260, 450))
exit_btn = pygame.image.load('images/buttons/exit_btn.png')
exit_btn_rect = exit_btn.get_rect(center=(550, 456))
options_btn = pygame.image.load('images/buttons/options_btn.png')
options_btn_rect = options_btn.get_rect(center=(410, 550))
music_on_btn = pygame.image.load('images/buttons/on_music_btn.png')
music_on_btn_rect = music_on_btn.get_rect(center=(70, 70))
music_off_btn = pygame.image.load('images/buttons/off_music_btn.png')
music_off_btn_rect = music_off_btn.get_rect(center=(70, 70))
plus_volume_btn = pygame.image.load('images/buttons/plus_volume_btn.png')
plus_volume_btn_rect = plus_volume_btn.get_rect(center=(70, 170))
minus_volume_btn = pygame.image.load('images/buttons/minus_volume_btn.png')
minus_volume_btn_rect = minus_volume_btn.get_rect(center=(70, 320))
bests_btn = pygame.image.load('images/buttons/cup_bests_btn.png')
bests_btn_rect = bests_btn.get_rect(center=(750, 540))
home_btn_bests = pygame.image.load('images/buttons/home_btn.png')
home_btn_bests_rect = home_btn_bests.get_rect(center=(70, 540))
select_track_btn_1 = pygame.image.load('images/buttons/select_track_btn_1.png')
select_track_btn_1_rect = select_track_btn_1.get_rect(center=(180, 560))
select_track_btn_2 = pygame.image.load('images/buttons/select_track_btn_2.png')
select_track_btn_2_rect = select_track_btn_2.get_rect(center=(260, 560))
replay_music_btn = pygame.image.load('images/buttons/replay_music_btn.png')
replay_music_btn_rect = replay_music_btn.get_rect(center=(70, 360))
clicked_replay_music_btn = pygame.image.load('images/buttons/clicked_replay_music_btn.png')
save_results_btn = pygame.image.load('images/buttons/save_results_btn.png')
save_results_btn_rect = save_results_btn.get_rect(center=(720, 320))
select_record_btn_1 = pygame.image.load('images/buttons/select_record_btn_1.png')
select_record_btn_1_rect = select_record_btn_1.get_rect(center=(200, 550))
select_record_btn_2 = pygame.image.load('images/buttons/select_record_btn_2.png')
select_record_btn_2_rect = select_record_btn_2.get_rect(center=(650, 550))
clear_best_btn = pygame.image.load('images/buttons/clear_best_btn.png')
clear_best_btn_rect = clear_best_btn.get_rect(center=(730, 550))
change_your_nickname_btn = pygame.image.load('images/buttons/change_your_nickname_btn.png')
change_your_nickname_btn_rect = change_your_nickname_btn.get_rect(center=(70, 540))

img = 0
fps = 60
play_music = [1]
clock = pygame.time.Clock()
loading_animation()

pygame.quit()
